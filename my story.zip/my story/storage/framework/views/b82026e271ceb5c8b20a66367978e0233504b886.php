<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Hospital Admin</title>

  <!-- Favicons -->
  <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">
  <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">
  <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->


  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_page.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('lib/advanced-datatable/css/demo_table.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo e(asset('lib/advanced-datatable/css/DT_bootstrap.css')); ?>" />
  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('lib/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!--external css-->
  <link href="<?php echo e(asset('lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/zabuto_calendar.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('lib/gritter/css/jquery.gritter.css')); ?>" />
  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/style-responsive.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(asset('lib/chart-master/Chart.js')); ?>"></script>
  <section id="container">
<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<div class="container">
    <?php echo $__env->make('include.messagess', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </section>
  <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>

  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script src="<?php echo e(asset('lib/jquery.sparkline.js')); ?>"></script>
  <!--common script for all pages-->
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter/js/jquery.gritter.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/gritter-conf.js')); ?>"></script>
  <!--script for this page-->
  <script src="<?php echo e(asset('lib/sparkline-chart.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/zabuto_calendar.js')); ?>"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      var unique_id = $.gritter.add({
        // (string | mandatory) the heading of the notification
        title: 'Welcome to Dashio!',
        // (string | mandatory) the text inside the notification
        text: 'Hover me to enable the Close Button. You can hide the left sidebar clicking on the button next to the logo.',
        // (string | optional) the image to display on the left
        image: 'img/ui-sam.jpg',
        // (bool | optional) if you want it to fade out on its own or just sit there
        sticky: false,
        // (int | optional) the time you want it to be alive for before fading out
        time: 8000,
        // (string | optional) the class name you want to apply to that specific message
        class_name: 'my-sticky-class'
      });

      return false;
    });
  </script>
  <script type="application/javascript">
    $(document).ready(function() {
      $("#date-popover").popover({
        html: true,
        trigger: "manual"
      });
      $("#date-popover").hide();
      $("#date-popover").click(function(e) {
        $(this).hide();
      });

      $("#my-calendar").zabuto_calendar({
        action: function() {
          return myDateFunction(this.id, false);
        },
        action_nav: function() {
          return myNavFunction(this.id);
        },
        ajax: {
          url: "show_data.php?action=1",
          modal: true
        },
        legend: [{
            type: "text",
            label: "Special event",
            badge: "00"
          },
          {
            type: "block",
            label: "Regular event",
          }
        ]
      });
    });

    function myNavFunction(id) {
      $("#date-popover").hide();
      var nav = $("#" + id).data("navigation");
      var to = $("#" + id).data("to");
      console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
    }
    <script src="<?php echo e(asset('lib/jquery/jquery.min.js')); ?>"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
  <script class="include" type="text/javascript" src="<?php echo e(asset('lib/jquery.dcjqaccordion.2.7.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.scrollTo.min.js')); ?>"></script>
  <script src="<?php echo e(asset('lib/jquery.nicescroll.js')); ?>" type="text/javascript"></script>
  <script type="text/javascript" language="javascript" src="<?php echo e(asset('lib/advanced-datatable/js/jquery.dataTables.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('lib/advanced-datatable/js/DT_bootstrap.js')); ?>"></script>
  <!--common script for all pages-->
  <script src="<?php echo e(asset('lib/common-scripts.js')); ?>"></script>
  <!--script for this page-->
  <script type="text/javascript">
    /* Formating function for row details */
    function fnFormatDetails(oTable, nTr) {
      var aData = oTable.fnGetData(nTr);
      var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">';
      sOut += '<tr><td>التخصص:</td><td>' + aData[1] + ' ' + aData[4] + '</td></tr>';
      sOut += '<tr><td> الموقع :</td><td>' + aData[3] + '</td></tr>';
      sOut += '<tr><td>Extra info:</td><td>And any further details here (images etc)</td></tr>';
      sOut += '</table>';

      return sOut;
    }

    $(document).ready(function() {
      /*
       * Insert a 'details' column to the table
       */
      var nCloneTh = document.createElement('th');
      var nCloneTd = document.createElement('td');
      nCloneTd.innerHTML = '<img src="<?php echo e(asset('lib/advanced-datatable/images/details_open.png')); ?>">';
      nCloneTd.className = "center";

      $('#hidden-table-info thead tr').each(function() {
        this.insertBefore(nCloneTh, this.childNodes[0]);
      });

      $('#hidden-table-info tbody tr').each(function() {
        this.insertBefore(nCloneTd.cloneNode(true), this.childNodes[0]);
      });

      /*
       * Initialse DataTables, with no sorting on the 'details' column
       */
      var oTable = $('#hidden-table-info').dataTable({
        "aoColumnDefs": [{
          "bSortable": false,
          "aTargets": [0]
        }],
        "aaSorting": [
          [1, 'asc']
        ]
      });

      /* Add event listener for opening and closing details
       * Note that the indicator for showing which row is open is not controlled by DataTables,
       * rather it is done here
       */
      $('#hidden-table-info tbody td img').live('click', function() {
        var nTr = $(this).parents('tr')[0];
        if (oTable.fnIsOpen(nTr)) {
          /* This row is already open - close it */
          this.src = "<?php echo e(asset('lib/advanced-datatable/media/images/details_open.png')); ?>";
          oTable.fnClose(nTr);
        } else {
          /* Open this row */
          this.src = "<?php echo e(asset('lib/advanced-datatable/images/details_close.png')); ?>";
          oTable.fnOpen(nTr, fnFormatDetails(oTable, nTr), 'details');
        }
      });
    });
  </script>
  </script>
<?php /**PATH C:\xampp\htdocs\my story\resources\views/include/master.blade.php ENDPATH**/ ?>