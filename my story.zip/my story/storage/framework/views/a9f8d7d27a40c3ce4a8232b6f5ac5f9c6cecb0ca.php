<?php $__env->startSection('content'); ?>

<section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i>Staff </h3>
      <div class="row mb">
        <!-- page start-->
        <div class="content-panel">
          <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                    <tr>
                      <th>No </th>
                      <th class="hidden-phone">Name</th>
                      <th class="hidden-phone">Title</th>
                      
                      
                      <th class="hidden-phone">staff</th>
                      <th class="hidden-phone">phone</th>
                      <th class="hidden-phone">email</th>
                      <th class="hidden-phone">Options</th>
                    </tr>
                  </thead>

                  <tbody>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeA">
                      <td><?php echo e($index+1); ?></td>
                      <td><?php echo e($staff->name); ?></td>
                      <td class="hidden-phone"><?php echo e($staff->title); ?></td>
                      <td class="hidden-phone">
                                <?php echo e($staff->phone); ?>

                      </td>
                      <td class="hidden-phone">
                        <?php echo e($staff->email); ?>


                    </td>
                      
                      
                      <td class="hidden-phone"><?php echo e($staff->pharmacy->name); ?></td>
                      <td>
                        
                        <a href="<?php echo e('/staff/update/'.$staff->id); ?>" class=" btn btn-primary btn-dark" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-pencil"></i></a>
                        <a href="<?php echo e('/staff/delete/'.$staff->id); ?>" class=" btn btn-danger btn-light" data-toggle="tooltip" data-placement="top" title="delete"><i class="fa fa-trash-o "></i></a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
            </table>
          </div>
        </div>
        <!-- page end-->
      </div>
      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>



<?php $__env->stopSection(); ?>
<head>
    <title>
       Show Doctor
    </title>

</head>

<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my story\resources\views/staff/show.blade.php ENDPATH**/ ?>