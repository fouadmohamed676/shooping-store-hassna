<?php $__env->startSection('content'); ?>

<section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i> Show Hospital :</h3>
      <div class="row mb">
        <!-- page start-->
        <div class="content-panel">
          <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
              <thead>
                <tr>
                  <th>No </th>
                  <th>Name</th>
                  <th class="hidden-phone">Title</th>
                  <th class="hidden-phone">Specialization</th>
                  <th class="hidden-phone">CSS grade</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $hospital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospitals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="gradeA">
                    <td><?php echo e($hospitals->id); ?></td>
                  <td><strong><?php echo e($hospitals->dis); ?></strong></td>
                  <td class="hidden-phone"><?php echo e($hospitals->address); ?></td>
                  <td class=" hidden-phone"><?php echo e($hospitals->specialization_hospital); ?></td>
                  <td class=" hidden-phone"><?php echo e($hospitals->address); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        <!-- page end-->
      </div>
      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my story\resources\views/hospital/show.blade.php ENDPATH**/ ?>