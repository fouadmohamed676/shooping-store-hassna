<?php $__env->startSection('content'); ?>


  <!--main content start-->
  <section id="main-content">
    <section class="wrapper">

     <center>

        <h2>
            <i class="fa fa-angle-right">
            </i> Wellcom Admin </h2>
            
    </center>
      <!-- BASIC FORM VALIDATION -->

      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>








<?php $__env->stopSection(); ?>

<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my story\resources\views/welcome.blade.php ENDPATH**/ ?>