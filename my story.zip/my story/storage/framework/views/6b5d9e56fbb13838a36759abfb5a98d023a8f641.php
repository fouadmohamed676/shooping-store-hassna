<?php $__env->startSection('content'); ?>


  <!--main content start-->
  <section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i> Update Doctor </h3>

      <div class="row mt">
        <div class="col-lg-12">
          <h4><i class="fa fa-angle-right"></i> Advanced Form Validations</h4>
          <div class="form-panel">
            <div class="form">
              <form class="cmxform form-horizontal style-form" id="signupForm" method="POST" action="<?php echo e(url('doctors/save_update/'.$doctors->id)); ?>">
                
                <?php echo csrf_field(); ?>
               <?php echo method_field('put'); ?>
                <div class="form-group ">
                  <label for="firstname" class="control-label col-lg-2">Name</label>
                  <div class="col-lg-10">
                    <input class=" form-control" id="firstname" required value="<?php echo e($doctors->name); ?>" name="name" type="text" />
                  </div>
                </div>
                <div class="form-group ">
                  <label for="lastname" class="control-label col-lg-2">Title</label>
                  <div class="col-lg-10">
                    <input class=" form-control" id="lastname" required value="<?php echo e($doctors->title); ?>"  name="title" type="text" />
                  </div>
                </div>
                <div class="form-group ">
                  <label for="username" class="control-label col-lg-2">Specialization</label>
                  <div class="col-lg-10">
                    <select class="form-control"  value="<?php echo e($doctors->specialization_id); ?>"  name="specialization_id">
                        <?php $__currentLoopData = $speci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospitals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hospitals->id); ?>" <?php echo e($hospitals->id == $doctors->specialization_id  ? "Selected":""); ?>>
                            <?php echo e($hospitals->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group ">
                  <label for="gender" class="control-label col-lg-2">gender</label>
                  <div class="col-lg-10">
                    <select class="form-control" required value="<?php echo e($doctors->gender); ?>"  name="gender">
                        
                        <option value="male" <?php echo e(($doctors->gender=="male" ? "Selected":"" )); ?>>Male</option>
                        <option value="female" <?php echo e(($doctors->gender=="female" ? "Selected":"" )); ?>>Female</option>
                      </select>
                  </div>
                </div>
                <div class="form-group ">
                  <label for="name" class="control-label col-lg-2">Hospital</label>
                  <div class="col-lg-10">
                    <select class="form-control" name="resoureceName">

                        <?php $__currentLoopData = $hospital; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospitals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hospitals->dis); ?>" <?php echo e($hospitals->id == $hospitals->hospital_id  ? "Selected":""); ?>>
                            <?php echo e($hospitals->dis); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
                <div class="form-group ">
                  <label for="email" class="control-label col-lg-2">Email</label>
                  <div class="col-lg-10">
                    <input class="form-control " id="email" value="<?php echo e($doctors->email); ?>" name="email" type="email" />
                  </div>
                </div>
                <div class="form-group ">
                    <label for="name" class="control-label col-lg-2">Nationality </label>
                    <div class="col-lg-10">
                      <select class="form-control" name="nationality_id">
                          <?php $__currentLoopData = $nation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nationality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($nationality->id); ?>"<?php echo e($doctors->id == $doctors->nationality_id  ?  "selected" : ""); ?>><?php echo e($nationality->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                  </div>
                <div class="form-group ">
                    <label for="phone" class="control-label col-lg-2">Phone</label>
                    <div class="col-lg-10">
                      <input class="form-control" value="<?php echo e($doctors->phone); ?>" required id="phone" name="phone" type="number" />
                    </div>
                  </div>
                <div class="form-group ">
                  <label for="agree" class="control-label col-lg-2 col-sm-3">Agree to Our Policy</label>
                  <div class="col-lg-10 col-sm-9">
                    <input type="checkbox" style="width: 20px" class="checkbox form-control" id="agree" name="agree" />
                  </div>
                </div>
                <div class="form-group ">
                  <label for="newsletter" class="control-label col-lg-2 col-sm-3">Receive the Newsletter</label>
                  <div class="col-lg-10 col-sm-9">
                    <input type="checkbox" style="width: 20px" class="checkbox form-control" id="newsletter" name="newsletter" />
                  </div>
                </div>
                <div class="form-group">
                  <div class="col-lg-offset-2 col-lg-10">
                    <button class="btn btn-theme" type="submit">Save</button>
                    <button class="btn btn-theme04" type="button">Cancel</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  </section>
<?php $__env->stopSection(); ?>
<head>
    <title>
       Update Doctor
    </title>
</head>

<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\my story\resources\views/doctors/update.blade.php ENDPATH**/ ?>