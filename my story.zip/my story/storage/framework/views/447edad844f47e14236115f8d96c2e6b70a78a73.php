
  <?php if(session('error')): ?>
    <div class="contanier">
   <p>

   </p>
               <div class="alert alert-danger">
                   <?php echo e(session('error')); ?>

               </div>
    </div>
               <?php endif; ?>


    <?php if(session('status')): ?>
    


        <div id="gritter-notice-wrapper" class="bottom-right">
            <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" style="">
                <div class="gritter-top">

                </div>
                <div class="gritter-item">
                    <div class="gritter-close" style="display: none;"></div>
                <img src="<?php echo e(asset('img/ui-sam.jpg')); ?>" class="gritter-image">
                <div class="gritter-with-image">
                    <span class="gritter-title"> Successfull !</span>
                    <p> <?php echo e(session('status')); ?></p>
                </div><div style="clear:both">
                    
                </div>
            </div>
            <div class="gritter-bottom">
                        </div>
                    </div>
                </div>


               


                

            


    
               <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\my story\resources\views/include/messagess.blade.php ENDPATH**/ ?>