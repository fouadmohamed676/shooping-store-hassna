<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
    use HasFactory;
    protected $table="staff";
    protected $fillable=['id','name','title','email','phone','pharmacy_id'];
    public $timestamps=false;

    public function pharamc(){
        return $this-> belongsTo(Pharamcy::class,'pharmacy_id','id');
    }
}
