<?php

namespace App\Models;
use App\Models\Doctor;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NationalityDoctor extends Model
{
    use HasFactory;

    protected $table="nationality";
    protected $fillable=['id','name'];
    public $timestamps=false;

    public function doctornationality(){
        return $this-> hasMany(Doctor::class,'nationality_id','id');
    }

}
