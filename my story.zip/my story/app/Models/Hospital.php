<?php

namespace App\Models;
use App\Models\Doctor;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Hospital extends Model
{
    use HasFactory;
    protected $table="hospital";
    protected $fillable=['id','dis','address'];
    public $timestamps=false;
    public function doctor(){
        return $this-> hasMany(Doctor::class,'hospital_id','id');
    }

}
