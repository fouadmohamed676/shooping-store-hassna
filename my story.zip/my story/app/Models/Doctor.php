<?php

namespace App\Models;
use App\Models\Hospital;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    use HasFactory;

    protected $table="docotrs";

    protected $fillable=['name','title','hospital_id','nationality_id','specialization_id','gender','email','phone'];
    public $timestamps=false;

    ############ RELATIONSHIP ############
    public function hospital(){
        return $this->belongsTo(Hospital::class,'hospital_id');
    }

    public function speciliz(){
        return $this->belongsTo(SpecializationDoctor::class,'specialization_id');
    }

    public function national(){
        return $this->belongsTo(NationalityDoctor::class,'nationality_id');
    }
}
