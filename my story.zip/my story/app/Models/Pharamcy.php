<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pharamcy extends Model
{
    use HasFactory;
    protected $table="pharmacy";
    protected $fillable=['id','name','title','address','time_work','staff_id'];
    public $timestamps=false;

    // public function staff(){
    //     return $this-> belongsTo(Staff::class,'pharmacy_id','id');
    // }
    public function staffss(){
        return $this->hasMany(Staff::class,'staff_id','id');
    }
}
