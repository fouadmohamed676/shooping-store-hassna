<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Doctor;
use App\Models\Hospital;
use App\Models\NationalityDoctor;
use App\Models\SpecializationDoctor;
use App\Models\Pharamcy;
use App\Models\Staff;

class StaffController extends Controller
{
    public function dodne(){

        return "done";

    }


    public function staf($id){

        $staffs=Staff::find($id);
        // $pharm=Staff::with('pharamc')->get();
        $pharmacy=Pharamcy::with('staffss')->get();
        return view('staff.show',compact('staffs','pharmacy'));

    }


    public function show(){

        $staffs=Staff::all();
        // $pharm=Staff::with('pharamc')->get();
        $pharmacy=Pharamcy::with('staffss')->get();
        return view('staff.show',compact('staffs','pharmacy'));

    }
    public function create(){

        $staffs=Staff::with('pharamc')->get();
        $pharmacy=Pharamcy::with('staff')->get();
        // $nation=NationalityDoctor::with('doctornationality')->get();
        return view('doctors.create',compact('staffs','pharmacy'));

    }

    public function save(Request $request){

        $validateData=$request->validate([
            'title'=>'required:docotrs',
            'name'=>'required',
            'email' => 'email',
         ]);
        $data=new Staff();
        $data->name=$request->name;
        $data->phone=$request->phone;
        $data->email=$request->email;
        $data->title=$request->title;
        $data->gender=$request->gender;
        $data->specialization_id=$request->specialization_id;
        $data->hospital_id=$request->hospital_id;
        $data->save();
        if($data){
            return redirect('/doctors/show')->with('status','Docotr Insert Successfully');
      }else{

         return back()->with('fail', ' Something Wrong ..!');

    }

}
public function update($id){

        $doctors=Doctor::find($id);
        $hospital=Hospital::with('doctor')->get();
        $speci=SpecializationDoctor::with('doctorSpecilization')->get();
        $nation=NationalityDoctor::with('doctornationality')->get();
    return view('doctors.update',compact('hospital','speci','nation','doctors'));
}
public function edit(Request $request,$id){

    $doctors=Doctor::find($id);
    $doctors->name = $request->input('name');
    $doctors->phone = $request->input('phone');
    $doctors->title = $request->input('title');
    $doctors->gender = $request->input('gender');
    $doctors->specialization_id = $request->input('specialization_id');
    $doctors->hospital_id = $request->input('hospital_id');
    $doctors->email = $request->input('email');
    $doctors->update();
    if($doctors){

        return redirect()->route('doctors.show')->with('status','Docotr Updated Successfully');

  }else{
     return back()->with('fail', ' Something Wrong ..!');
}
}
public function destroy($id){
    $data=Doctor::find($id);
    $data->delete();
    return redirect()->route('doctors.show')->with('status','Docotr deleted Successfully');;
}
}
