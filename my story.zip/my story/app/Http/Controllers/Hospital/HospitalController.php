<?php

namespace App\Http\Controllers\Hospital;

use App\Http\Controllers\Controller;
use App\Models\Hospital;
use Illuminate\Http\Request;

class HospitalController extends Controller
{
    public function dodne(){
        return "done";
    }
    public function show(){
        $hospital=Hospital::all();
        return view('hospital.show',compact('hospital'));
    }
}
