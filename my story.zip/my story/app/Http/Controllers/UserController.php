<?php

namespace App\Http\Controllers;
use App\Models\Hospital;
use App\Models\Doctor;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function hasOneRelation(){
        $doc=Doctor::all();
        $done=Hospital::with('doctor')->find(2);
        // $done=Doctor::with('hospital')->find(2);
        return response()->json($done);
    }
}
