@extends('include.master')
@section('content')

<section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i>Staff </h3>
      <div class="row mb">
        <!-- page start-->
        <div class="content-panel">
          <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                    <tr>
                      <th>No </th>
                      <th class="hidden-phone">Name</th>
                      <th class="hidden-phone">Title</th>
                      <th class="hidden-phone">Staff</th>
                     {{-- <th class="hidden-phone">Nationality</th>
                      <th class="hidden-phone">gender</th>
                      <th class="hidden-phone">email</th>
                      <th class="hidden-phone">phone</th> --}}
                      <th class="hidden-phone">Options</th>
                    </tr>
                  </thead>

                  <tbody>
                    @foreach ($pharamcys as $index=>$pharamcy)
                    <tr class="gradeA">
                      {{-- <td>{{$index+1}}</td> --}}
                      <td>{{$pharamcy->staffs->name}}</td>
                      {{-- <td class="hidden-phone">{{$pharamcy->title}}</td> --}}
                      <td class="hidden-phone">
                        <a href="{{'/pharamcy/update/'.$pharamcy->id}}" class=" btn btn-primary btn-dark" data-toggle="tooltip" data-placement="top" title="عرض الاطباء"><i class="fa fa-user"></i></a>

                                {{-- {{$pharamcy->hospital->dis}} --}}
                      </td>
                      {{-- <td class="hidden-phone"> --}}
                        {{-- {{$pharamcy->national->name}} --}}

                    {{-- </td> --}}
                      {{-- <td class="hidden-phone">
                        <span class="label label-success label-mini">{{$pharamcy->gender}}</span>
                      </td> --}}
                      {{-- <td class="center hidden-phone">{{$pharamcy->email}}</td> --}}
                      {{-- <td class="hidden-phone">{{$pharamcy->phone}}</td> --}}
                      <td>
                        {{-- <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button> --}}
                        <a href="{{'/pharamcy/update/'.$pharamcy->id}}" class=" btn btn-primary btn-dark" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-pencil"></i></a>
                        <a href="{{'/pharamcy/delete/'.$pharamcy->id}}" class=" btn btn-danger btn-light" data-toggle="tooltip" data-placement="top" title="delete"><i class="fa fa-trash-o "></i></a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
            </table>
          </div>
        </div>
        <!-- page end-->
      </div>
      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>



@endsection
<head>
    <title>
       Show Doctor
    </title>

</head>
