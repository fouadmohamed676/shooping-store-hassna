@extends('include.master')
@section('content')

<section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i> Show Hospital :</h3>
      <div class="row mb">
        <!-- page start-->
        <div class="content-panel">
          <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
              <thead>
                <tr>
                  <th>No </th>
                  <th>Name</th>
                  <th class="hidden-phone">Title</th>
                  <th class="hidden-phone">Specialization</th>
                  <th class="hidden-phone">CSS grade</th>
                </tr>
              </thead>
              <tbody>
                @foreach ($hospital as $hospitals)
                <tr class="gradeA">
                    <td>{{$hospitals->id}}</td>
                  <td><strong>{{$hospitals->dis}}</strong></td>
                  <td class="hidden-phone">{{$hospitals->address}}</td>
                  <td class=" hidden-phone">{{$hospitals->specialization_hospital}}</td>
                  <td class=" hidden-phone">{{$hospitals->address}}</td>
                </tr>
                @endforeach
              </tbody>
            </table>
          </div>
        </div>
        <!-- page end-->
      </div>
      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>



@endsection
