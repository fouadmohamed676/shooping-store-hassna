@extends('include.master')
@section('content')

<section id="main-content">
    <section class="wrapper">
      <h3><i class="fa fa-angle-right"></i>Staff </h3>
      <div class="row mb">
        <!-- page start-->
        <div class="content-panel">
          <div class="adv-table">
            <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered" id="hidden-table-info">
                <thead>
                    <tr>
                      <th>No </th>
                      <th class="hidden-phone">Name</th>
                      <th class="hidden-phone">Title</th>
                      {{-- <th class="hidden-phone">Hospital</th> --}}
                      {{-- <th class="hidden-phone">Nationality</th> --}}
                      <th class="hidden-phone">staff</th>
                      <th class="hidden-phone">phone</th>
                      <th class="hidden-phone">email</th>
                      <th class="hidden-phone">Options</th>
                    </tr>
                  </thead>

                  <tbody>
                    @foreach ($staffs as $index=>$staff)
                    <tr class="gradeA">
                      <td>{{$index+1}}</td>
                      <td>{{$staff->name}}</td>
                      <td class="hidden-phone">{{$staff->title}}</td>
                      <td class="hidden-phone">
                                {{$staff->phone}}
                      </td>
                      <td class="hidden-phone">
                        {{$staff->email}}

                    </td>
                      {{-- <td class="hidden-phone">
                        <span class="label label-success label-mini">{{$staff->gender}}</span>
                      </td> --}}
                      {{-- <td class="center hidden-phone">{{$staff->email}}</td> --}}
                      <td class="hidden-phone">{{$staff->pharmacy->name}}</td>
                      <td>
                        {{-- <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button> --}}
                        <a href="{{'/staff/update/'.$staff->id}}" class=" btn btn-primary btn-dark" data-toggle="tooltip" data-placement="top" title="Update"><i class="fa fa-pencil"></i></a>
                        <a href="{{'/staff/delete/'.$staff->id}}" class=" btn btn-danger btn-light" data-toggle="tooltip" data-placement="top" title="delete"><i class="fa fa-trash-o "></i></a>
                      </td>
                    </tr>
                    @endforeach
                  </tbody>
            </table>
          </div>
        </div>
        <!-- page end-->
      </div>
      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>



@endsection
<head>
    <title>
       Show Doctor
    </title>

</head>
