@extends('include.master')
@section('content')


  <!--main content start-->
  <section id="main-content">
    <section class="wrapper">

     <center>

        <h2>
            <i class="fa fa-angle-right">
            </i> Wellcom Admin </h2>
            
    </center>
      <!-- BASIC FORM VALIDATION -->

      <!-- /row -->
    </section>
    <!-- /wrapper -->
  </section>








@endsection
