
  @if (session('error'))
    <div class="contanier">
   <p>

   </p>
               <div class="alert alert-danger">
                   {{ session('error') }}
               </div>
    </div>
               @endif


    @if (session('status'))
    {{-- <div class="contanier"> --}}


        <div id="gritter-notice-wrapper" class="bottom-right">
            <div id="gritter-item-1" class="gritter-item-wrapper my-sticky-class" style="">
                <div class="gritter-top">

                </div>
                <div class="gritter-item">
                    <div class="gritter-close" style="display: none;"></div>
                <img src="{{asset('img/ui-sam.jpg')}}" class="gritter-image">
                <div class="gritter-with-image">
                    <span class="gritter-title"> Successfull !</span>
                    <p> {{ session('status') }}</p>
                </div><div style="clear:both">
                    {{-- <i <i class="fa fa-calendar" aria-hidden="true"></i> --}}
                </div>
            </div>
            <div class="gritter-bottom">
                        </div>
                    </div>
                </div>


               {{-- <div class="alert alert-success"> --}}


                {{-- {{ session('status') }} --}}

            {{-- </div> --}}


    {{-- </div> --}}
               @endif
