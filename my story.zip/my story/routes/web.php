<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Doctors\DoctorsController;
use App\Http\Controllers\Hospital\HospitalController;
use App\Http\Controllers\Pharamcy\PharamcyController;
use App\Http\Controllers\Staff\StaffController;

Route::get('/', function () {
    return view('welcome');
    // :controller Doctors\DoctorsController
    // HospitalController
});
Route::get('/getdata', [UserController::class, 'hasOneRelation']);


Route::group(['prefix' => 'doctors'], function()
{
Route::get('/show', [DoctorsController::class, 'show'])->name('doctors.show');
Route::get('/create', [DoctorsController::class, 'create'])->name('doctors.create');
Route::post('/save', [DoctorsController::class, 'save'])->name('doctors.save');
Route::get('/update/{id}', [DoctorsController::class, 'update']);
Route::put('/save_update/{id}', [DoctorsController::class, 'edit']);
Route::get('/delete/{id}', [DoctorsController::class , 'destroy'])->name('doctors.delete');
});

Route::group(['prefix' => 'hospital'], function()
{
Route::get('/show', [HospitalController::class, 'show'])->name('hospital.show');
Route::post('/create', [HospitalController::class, 'create'])->name('hospital.create');
Route::get('delete/{id}', [HospitalController::class , 'destroy'])->name('hospital.delete');
});
Route::group(['prefix' => 'pharmacy'], function()
{
Route::get('/show', [PharamcyController::class, 'show'])->name('pharmacy.show');
Route::post('/create', [PharamcyController::class, 'create'])->name('pharmacy.create');
Route::get('delete/{id}', [PharamcyController::class , 'destroy'])->name('pharmacy.delete');
Route::get('staff_pharmacy/{id}', [PharamcyController::class, 'staff'])->name('pharmacy.staff_pharmacy');
// Route::get('/save_update/{id}', [PharamcyController::class, 'edit']);
});
Route::group(['prefix' => 'staff'], function()
{
Route::get('/show', [StaffController::class, 'show'])->name('staff.show');
Route::post('/create', [StaffController::class, 'create'])->name('staff.create');
Route::get('delete/{id}', [StaffController::class , 'destroy'])->name('staff.delete');
});
